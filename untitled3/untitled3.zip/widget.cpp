#include "widget.h"
#include "ui_widget.h"
#include "login.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //设置无边框显示
    this->setWindowFlags(Qt::FramelessWindowHint);
    //设置菜单按钮
    ui->pushButton->setFlat(true);
    ui->pushButton_2->setFlat(true);
    ui->pushButton_3->setFlat(true);
    //设置初始显示页面
    ui->stackedWidget->setCurrentIndex(0);
    //界面初始设置
    ui->listWidget->hide();
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    connect(ui->toolButton, SIGNAL(clicked()), this, SLOT(windowclosed()));
    QMenu *menu = new QMenu;
    QAction *click = new QAction("设置",this);
    menu->addAction(click);
    ui->pushButton_6->setMenu(menu);
    //给是否移动的标志初始化为false.
    m_move = false;
    //用户名和头像初始化
    userName = "administrator";
    headImage = "C:/Users/24957/Documents/untitled3/defaultheadimage.jpg";
}

Widget::~Widget()
{
    delete ui;
}

void Widget::Initial(QString username)
{
    //设置用户个人信息
    //设置头像和用户名
    QImage *image;
    image = new QImage();
    if(image->load(headImage))
    {

        QGraphicsScene *scene = new QGraphicsScene;
        scene->addPixmap(QPixmap::fromImage(*image).scaled(31,31,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
        ui->graphicsView->setScene(scene);
        ui->graphicsView->resize(31, 31);
        ui->graphicsView->show();
    }
    userName=username;
    ui->label_2->setText(userName);

}

void Widget::mousePressEvent(QMouseEvent *event)
{
    //当鼠标左键点击时.
        if (event->button() == Qt::LeftButton)
        {
            m_move = true;
            //记录鼠标的世界坐标.
            m_startPoint = event->globalPos();
            //记录窗体的世界坐标.
            m_windowPoint = this->frameGeometry().topLeft();
        }
}

void Widget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
        {
            //移动中的鼠标位置相对于初始位置的相对位置.
            QPoint relativePos = event->globalPos() - m_startPoint;
            //然后移动窗体即可.
            this->move(m_windowPoint + relativePos );
    }
}

void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
        {
            //改变移动状态.
            m_move = false;
        }
}

void Widget::on_pushButton_clicked()
{
    ui->pushButton->setDown(true);
    ui->pushButton_2->setDown(false);
    ui->pushButton_3->setDown(false);
    ui->stackedWidget->setCurrentIndex(0);

}

void Widget::on_pushButton_2_clicked()
{
    ui->pushButton_2->setDown(true);
    ui->pushButton->setDown(false);
    ui->pushButton_3->setDown(false);
    ui->stackedWidget->setCurrentIndex(1);
}

void Widget::on_pushButton_3_clicked()
{
    ui->pushButton_3->setDown(true);
    ui->pushButton->setDown(false);
    ui->pushButton_2->setDown(false);
    ui->stackedWidget->setCurrentIndex(2);
}

void Widget::on_lineEdit_2_textChanged(const QString &arg1)
{
    QString empty = arg1;
    ui->listWidget->clear();
    vector<string> temp = trie.get_str_pre(ui->lineEdit_2->text().toStdString());
    if(ui->lineEdit_2->text()!=""&&temp.size()!=0){
        for(auto&str:temp){
            QListWidgetItem *addItem = new QListWidgetItem(ui->listWidget);
            addItem->setText(QString::fromStdString(str));
        }
        ui->listWidget->show();
    }else {
        ui->listWidget->hide();
    }

}


void Widget::on_listWidget_itemClicked(QListWidgetItem *item)
{
    qDebug()<<item->text()<<endl;
    ui->stackedWidget->setCurrentIndex(3);
    ui->label_7->setText(item->text());
    ui->label_8->setText(QString::fromStdString(hashmap.find(item->text().toStdString())));
    ui->listWidget->clearSelection();
}

void Widget::on_pushButton_4_clicked()
{
    qDebug()<<"target:"<<ui->lineEdit->text();
    ui->stackedWidget->setCurrentIndex(3);
    string temp = hashmap.find(ui->lineEdit->text().toStdString());
    if(temp!=""){
        qDebug()<<"find";
        ui->label_7->setText(ui->lineEdit->text());
        ui->label_8->setText(QString::fromStdString(temp));
    }else{
        qDebug()<<"notfind";
        ui->label_7->setText("未找到该单词！");
        ui->label_8->setText("");
    }
}

void Widget::on_pushButton_5_clicked()
{
    QImage *image;
    image = new QImage();
    QString fileName = QFileDialog::getOpenFileName(
                    this, "open image file",
                    ".",
                    "Image files (*.bmp *.jpg *.pbm *.pgm *.png *.ppm *.xbm *.xpm);;All files (*.*)");
    if(fileName != "")
    {
        if(image->load(fileName))
        {

            QGraphicsScene *scene = new QGraphicsScene;
            scene->addPixmap(QPixmap::fromImage(*image).scaled(31,31,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
            ui->graphicsView->setScene(scene);
            ui->graphicsView->resize(31, 31);
            ui->graphicsView->show();
        }
    }
    headImage = fileName;
    qDebug()<<"filepath:"<<headImage<<endl;
}

void Widget::windowclosed()
{
    this->close();
}


void Widget::on_pushButton_7_clicked()
{
    ifstream in("C:/Users/24957/Documents/untitled3/word.txt");
    if(!in.is_open()){
        qDebug()<<"FileOpenError";
        return;
    }
    string str;
    while (!in.eof()) {
        string temp1;
        string temp2;
        in>>temp1;
        in>>temp2;
        hashmap.insert(temp1,temp2);
        trie.insert_string(temp1);
        cout<<"("<<temp1<<","<<temp2<<")";
    }
    cout<<endl;
}
