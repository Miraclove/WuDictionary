#include "hashmap.h"
HashMap::HashMap()
{

}

int HashMap::HashValue(QString inputkey)
{
    qDebug()<<"input:"<<inputkey;
    QString str = QString::fromStdString(MD5(inputkey.toStdString()).toString());
    bool ok;
    qDebug()<<str.toInt(&ok,16);
    return 0;
}
