#include "login.h"
#include "ui_login.h"
#include "widget.h"

Login::Login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    widget = new Widget;
    this->setWindowFlags(Qt::FramelessWindowHint);
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
    in = new QPropertyAnimation(widget,"windowOpacity");
    in->setDuration(300);
    in->setStartValue(0);
    in->setEndValue(1);
    out = new QPropertyAnimation(this,"windowOpacity");
    connect(out,&QPropertyAnimation::finished,[=]{
        this->close();
        widget->Initial(ui->lineEdit->text());
        in->start();
        widget->show();
    });
    out->setDuration(300);
    out->setStartValue(1);
    out->setEndValue(0);
}

Login::~Login()
{
    delete ui;
}

void Login::on_pushButton_clicked()
{
    out->start();
}
