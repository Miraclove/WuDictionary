#include "trie.h"

//插入字符串，构建字典树
void Trie::insert_string(const string& str)
{
    if (!root || str.empty())
        return;

    trieNode* currentNode = root;

    for (auto& chr : str)
    {
        auto Iter = currentNode->child.find(chr);
        if (Iter == currentNode->child.end())
        {
            //如果当前字符不在字典树中，新建一个节点插入
            trieNode* newNode = new trieNode();
            currentNode->child.insert(make_pair(chr, newNode));
            currentNode = newNode;
        }
        else
        {
            //如果当前字符在字典书中，则将当前节点指向它的孩子
            currentNode = Iter->second;
        }
    }
    currentNode->count++;
}
//查找以str为前缀的节点
trieNode* Trie::search_str_pre(const string& str)
{
    if (!root || str.empty())
        return nullptr;

    trieNode* currentNode = root;
    for (auto& chr : str)
    {
        auto Iter = currentNode->child.find(chr);
        if (Iter != currentNode->child.end())
        {
            currentNode = Iter->second;
        }
        else
            return nullptr;
    }

    return currentNode;
}
//查找以str为前缀的所有字符串，保存在vector中返回
vector<string> Trie::get_str_pre(const string& str)
{
    vector<string> ret;
    trieNode* pre = search_str_pre(str);
    if (pre)
    {
        add_str(pre, str, ret);
    }
    return ret;
}
//将preNode的所有子节点中字符串加入str前缀，然后插入到vector中
void Trie::add_str(trieNode* preNode, string str, vector<string>& ret)
{
    for (auto Iter = preNode->child.begin(); Iter != preNode->child.end(); ++Iter)
    {
        add_str(Iter->second, str + Iter->first, ret);
    }
    if (preNode->count != 0)
        ret.push_back(str);
}
