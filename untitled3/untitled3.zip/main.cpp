#include "widget.h"
#include <QApplication>
#include"login.h"
#include"trie.h"
#include<iostream>
#include<QTextCodec>
using namespace std;
#include"hashmap.h"
int main(int argc, char *argv[])
{
    QGuiApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication a(argc, argv);
    Login login;
    login.show();
    return a.exec();
}
