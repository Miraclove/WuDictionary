#ifndef TRIE_H
#define TRIE_H


#include<iostream>
#include<string>
#include<map>
#include<vector>
using namespace std;
//字典树节点
class trieNode
{
public:
    trieNode() :count(0) {}
    //以当前节点结尾的字符串的个数
    int count;
    map<char, trieNode*> child;
};
//字典树
class Trie
{
public:
    Trie() { root = new trieNode(); }
    void insert_string(const string& str);
    vector<string> get_str_pre(const string& str);
private:
    //辅助函数
    void add_str(trieNode* preNode, string str, vector<string>& ret);
    trieNode* search_str_pre(const string& str);

    trieNode* root;
};

#endif // TRIE_H
