#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QListWidgetItem>
#include<QFile>
#include<QHBoxLayout>
#include<QSignalMapper>
#include<QDebug>
#include<QFileDialog>
#include<QImage>
#include<QPixmap>
#include<QMenu>
#include<QAction>
#include<QPoint>
#include<QMouseEvent>
#include<iostream>
#include<fstream>
#include<stdlib.h>
#include"hashmap.h"
#include"trie.h"
using namespace std;
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    QString userName;
    QString headImage;
    void Initial(QString username);
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_lineEdit_2_textChanged(const QString &arg1);

    void on_listWidget_itemClicked(QListWidgetItem *item);

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void windowclosed();

    void on_pushButton_7_clicked();

private:
    Ui::Widget *ui;
    bool m_move;
    QPoint m_startPoint;
    QPoint m_windowPoint;
    HashMap<string,string> hashmap;
    Trie trie;
};

#endif // WIDGET_H
